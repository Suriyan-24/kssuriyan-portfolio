const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const menu=$('.menu-toggle'),nav=$('.nav');
if(menu&&nav){menu.setAttribute('aria-expanded','false');menu.addEventListener('click',()=>{const o=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(o))});$$('a',nav).forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')))}
// Portrait: monogram is always shown; a real photo (assets/profile.jpg) replaces it only if it loads as a valid image.
const avatar=$('.avatar'),photo=$('.portrait');
if(avatar&&photo){const probe=new Image();probe.onload=()=>{if(probe.naturalWidth>1){photo.src=probe.src;photo.hidden=false;avatar.classList.add('has-photo')}};probe.src=photo.getAttribute('src')}
// Scroll progress + header state
const bar=document.createElement('div');bar.className='progress';document.body.prepend(bar);
const hdr=$('.site-header');let tick=false;
const onScroll=()=>{tick=false;const h=document.documentElement,max=h.scrollHeight-h.clientHeight;bar.style.transform=`scaleX(${max>0?scrollY/max:0})`;hdr&&hdr.classList.toggle('scrolled',scrollY>8)};
addEventListener('scroll',()=>{if(!tick){tick=true;requestAnimationFrame(onScroll)}},{passive:true});onScroll();
// Reveal on scroll (auto-tags content on every page, staggered per group)
const sel='.section-head,.highlight-card,.skill-card,.now-list>div,.quick-stats>div,.contact-band,.page-hero,.cert-group,.lead-card,.post-card,.cert-card,.project-card,.job,.actions,.timeline';
$$(sel).forEach(el=>el.classList.add('reveal'));
$$('.highlight-grid,.feature-grid,.skill-grid,.quick-stats,.cert-grid,.project-grid,.post-grid,.lead-grid,.now-list').forEach(g=>[...g.children].forEach((c,i)=>c.style.setProperty('--d',Math.min(i*.07,.35)+'s')));
const io='IntersectionObserver'in window?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}}),{threshold:.08,rootMargin:'0px 0px -40px 0px'}):null;
$$('.reveal').forEach(el=>io?io.observe(el):el.classList.add('visible'));
// Count-up stats
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
$$('[data-count]').forEach(el=>{const to=+el.dataset.count;if(reduce)return;const co=new IntersectionObserver(([e])=>{if(!e.isIntersecting)return;co.disconnect();el.textContent='0';const t0=performance.now(),d=1400;(function f(t){const p=Math.min((t-t0)/d,1);el.textContent=Math.round(to*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(f)})(t0)});co.observe(el)});
// Cursor spotlight on cards
$$('.highlight-card,.project-card,.cert-card,.post-card,.lead-card').forEach(c=>c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();c.style.setProperty('--mx',e.clientX-r.left+'px');c.style.setProperty('--my',e.clientY-r.top+'px')}));
